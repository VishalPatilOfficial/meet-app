const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const roomIdInput = document.getElementById('roomId');
const meetingLinkDiv = document.getElementById('meetingLink');
const createRoomButton = document.getElementById('createRoom');
const joinRoomButton = document.getElementById('joinRoom');
const hangUpButton = document.getElementById('hangUp');
const cameraToggleButton = document.getElementById('cameraToggle');
const micToggleButton = document.getElementById('micToggle');
const screenShareButton = document.getElementById('screenShare');
const copyLinkButton = document.getElementById('copyLink');
const chatInput = document.getElementById('messageInput');
const sendMessageButton = document.getElementById('sendMessage');
const messages = document.getElementById('messages');

let localStream;
let remoteStream;
let peerConnection;
let ws;
const servers = {
    iceServers: [
        {
            urls: 'stun:stun.l.google.com:19302'
        }
    ]
};

// Initialize WebSocket connection
ws = new WebSocket('ws://localhost:3000');

ws.onmessage = async (message) => {
    const signal = JSON.parse(message.data);
    if (signal.offer) {
        await handleOffer(signal.offer);
    } else if (signal.answer) {
        await handleAnswer(signal.answer);
    } else if (signal.ice) {
        await handleICECandidate(signal.ice);
    }
};

// Handle ICE candidates
async function handleICECandidate(candidate) {
    if (peerConnection) {
        await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
    }
}

// Handle offer
async function handleOffer(offer) {
    peerConnection = new RTCPeerConnection(servers);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            ws.send(JSON.stringify({ ice: event.candidate }));
        }
    };
    
    peerConnection.ontrack = event => {
        if (!remoteStream) {
            remoteStream = new MediaStream();
            remoteVideo.srcObject = remoteStream;
        }
        remoteStream.addTrack(event.track);
    };
    
    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
    
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    ws.send(JSON.stringify({ answer }));
}

// Handle answer
async function handleAnswer(answer) {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
}

// Initialize media devices
async function startLocalStream() {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        localVideo.srcObject = localStream;
    } catch (error) {
        console.error('Error accessing media devices.', error);
    }
}

// Create a room (host)
createRoomButton.addEventListener('click', async () => {
    const roomId = Math.random().toString(36).substring(7);
    roomIdInput.value = roomId;
    meetingLinkDiv.textContent = `Meeting Link: ${window.location.href}?roomId=${roomId}`;
    await startLocalStream();
    createRoom(roomId);
});

// Join an existing room
joinRoomButton.addEventListener('click', async () => {
    const roomId = roomIdInput.value;
    if (roomId) {
        await startLocalStream();
        joinRoom(roomId);
    } else {
        alert('Please enter a Room ID');
    }
});

// Hang up the call
hangUpButton.addEventListener('click', () => {
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
    }
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
    }
    remoteStream = null;
});

// Toggle camera
cameraToggleButton.addEventListener('click', () => {
    const videoTrack = localStream.getVideoTracks()[0];
    if (videoTrack.enabled) {
        videoTrack.enabled = false;
        cameraToggleButton.textContent = 'Camera On';
    } else {
        videoTrack.enabled = true;
        cameraToggleButton.textContent = 'Camera Off';
    }
});

// Toggle microphone
micToggleButton.addEventListener('click', () => {
    const audioTrack = localStream.getAudioTracks()[0];
    if (audioTrack.enabled) {
        audioTrack.enabled = false;
        micToggleButton.textContent = 'Mic On';
    } else {
        audioTrack.enabled = true;
        micToggleButton.textContent = 'Mic Off';
    }
});

// Share screen
screenShareButton.addEventListener('click', async () => {
    try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        screenStream.getTracks().forEach(track => peerConnection.addTrack(track, screenStream));
        screenStream.getTracks()[0].onended = () => {
            screenShareButton.textContent = 'Share Screen';
        };
        screenShareButton.textContent = 'Stop Sharing';
    } catch (error) {
        console.error('Error sharing screen:', error);
    }
});

// Copy meeting link to clipboard
copyLinkButton.addEventListener('click', () => {
    navigator.clipboard.writeText(meetingLinkDiv.textContent)
        .then(() => alert('Meeting link copied to clipboard'))
        .catch(err => console.error('Error copying link:', err));
});

// Create a room (for host)
async function createRoom(roomId) {
    peerConnection = new RTCPeerConnection(servers);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            ws.send(JSON.stringify({ ice: event.candidate }));
        }
    };
    
    peerConnection.ontrack = event => {
        if (!remoteStream) {
            remoteStream = new MediaStream();
            remoteVideo.srcObject = remoteStream;
        }
        remoteStream.addTrack(event.track);
    };
    
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    ws.send(JSON.stringify({ offer }));
}

// Join a room (for guest)
async function joinRoom(roomId) {
    peerConnection = new RTCPeerConnection(servers);
    
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            ws.send(JSON.stringify({ ice: event.candidate }));
        }
    };
    
    peerConnection.ontrack = event => {
        if (!remoteStream) {
            remoteStream = new MediaStream();
            remoteVideo.srcObject = remoteStream;
        }
        remoteStream.addTrack(event.track);
    };
    
    const offer = await fetch(`http://localhost:3000/${roomId}`)
        .then(response => response.json());
    
    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
    
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    ws.send(JSON.stringify({ answer }));
}

// Handle incoming messages
sendMessageButton.addEventListener('click', () => {
    const message = chatInput.value;
    if (message) {
        messages.innerHTML += `<p>${message}</p>`;
        chatInput.value = '';
        ws.send(message);
    }
});

ws.onmessage = (event) => {
    messages.innerHTML += `<p>${event.data}</p>`;
};
